import React from "react";
import ImgGallery from "./Components/Gallery/ImgGallery";

export default function App() {
    return (
        <>
            <ImgGallery />
        </>
    );
}

